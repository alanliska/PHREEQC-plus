CLS

OPEN "I", #1, "/data/data/cz.p/files/GeneralResults_P.txt"
INPUT #1, ThermoP$
LenghtDataP% = LEN(ThermoP$)
Lim0% = INSTR(ThermoP$, " ")
NameP$ = MID$(ThermoP$, 1, Lim0%-1)
Lim1% = INSTR(ThermoP$, " ", Lim0%+1)
FormulaP$ = MID$(ThermoP$, Lim0%+1, Lim1%-Lim0%-1)
Lim2% = INSTR(ThermoP$, " ", Lim1%+1)
MethodP$ = MID$(ThermoP$, Lim1%+1, Lim2%-Lim1%-1)
Lim3% = INSTR(ThermoP$, " ", Lim2%+1)
TotDummyP$ = MID$(ThermoP$, Lim2%+1, Lim3%-Lim2%-1)
Lim4% = INSTR(ThermoP$, " ", Lim3%+1)
HP$ = MID$(ThermoP$, Lim3%+1, Lim4%-Lim3%-1)
Lim5% = INSTR(ThermoP$, " ", Lim4%+1)
Dummy1P$ = MID$(ThermoP$, Lim4%+1, Lim5%-Lim4%-1)
Lim6% = INSTR(ThermoP$, " ", Lim5%+1)
Dummy2P$ = MID$(ThermoP$, Lim5%+1, Lim6%-Lim5%-1)
Lim7% = INSTR(ThermoP$, " ", Lim6%+1)
# manual: The variable SP represents the internal X11-Basic stack pointer. Do not name any other variable SP (or PC) since no value can be assigned to it.
SPc$ = MID$(ThermoP$, Lim6%+1, LenghtDataP%-Lim7%)
SPc = VAL(SPc$)
HP = VAL(HP$)
CLOSE #1

OPEN "I", #2, "/data/data/cz.p/files/GeneralResults_R.txt"
INPUT #2, ThermoR$
LenghtDataR% = LEN(ThermoR$)
Lim0% = INSTR(ThermoR$, " ")
NameR$ = MID$(ThermoR$, 1, Lim0%-1)
Lim1% = INSTR(ThermoR$, " ", Lim0%+1)
FormulaR$ = MID$(ThermoR$, Lim0%+1, Lim1%-Lim0%-1)
Lim2% = INSTR(ThermoR$, " ", Lim1%+1)
MethodR$ = MID$(ThermoR$, Lim1%+1, Lim2%-Lim1%-1)
Lim3% = INSTR(ThermoR$, " ", Lim2%+1)
TotDummyR$ = MID$(ThermoR$, Lim2%+1, Lim3%-Lim2%-1)
Lim4% = INSTR(ThermoR$, " ", Lim3%+1)
HR$ = MID$(ThermoR$, Lim3%+1, Lim4%-Lim3%-1)
Lim5% = INSTR(ThermoR$, " ", Lim4%+1)
Dummy1R$ = MID$(ThermoR$, Lim4%+1, Lim5%-Lim4%-1)
Lim6% = INSTR(ThermoR$, " ", Lim5%+1)
Dummy2R$ = MID$(ThermoR$, Lim5%+1, Lim6%-Lim5%-1)
Lim7% = INSTR(ThermoR$, " ", Lim6%+1)
SR$ = MID$(ThermoR$, Lim6%+1, LenghtDataR%-Lim7%)
SR = VAL(SR$)
HR = VAL(HR$)
CLOSE #2

OPEN "I", #5, "/data/data/cz.p/files/thermo_s_TS.txt"
INPUT #5, ThermoTS$
LenghtDataTS% = LEN(ThermoTS$)
Lim40% = INSTR(ThermoTS$, " ")
NameTS$ = MID$(ThermoTS$, 1, Lim40%-1)
Lim41% = INSTR(ThermoTS$, " ", Lim40%+1)
FormulaTS$ = MID$(ThermoTS$, Lim40%+1, Lim41%-Lim40%-1)
Lim42% = INSTR(ThermoTS$, " ", Lim41%+1)
MethodTS$ = MID$(ThermoTS$, Lim41%+1, Lim42%-Lim41%-1)
Lim43% = INSTR(ThermoTS$, " ", Lim42%+1)
TotDummyTS$ = MID$(ThermoTS$, Lim42%+1, Lim43%-Lim42%-1)
Lim44% = INSTR(ThermoTS$, " ", Lim43%+1)
HTS$ = MID$(ThermoTS$, Lim43%+1, Lim44%-Lim43%-1)
Lim45% = INSTR(ThermoTS$, " ", Lim44%+1)
Dummy1TS$ = MID$(ThermoTS$, Lim44%+1, Lim45%-Lim44%-1)
Lim46% = INSTR(ThermoTS$, " ", Lim45%+1)
Dummy2TS$ = MID$(ThermoTS$, Lim45%+1, Lim46%-Lim45%-1)
Lim47% = INSTR(ThermoTS$, " ", Lim46%+1)
STS$ = MID$(ThermoTS$, Lim46%+1, LenghtDataTS%-Lim47%)
STS = VAL(STS$)
HTS = VAL(HTS$)
CLOSE #5

OPEN "I", #6, "/data/data/cz.p/files/temperature.txt"
INPUT #6, Temp$
Temp = VAL(Temp$)
CLOSE #6

h = 6.626176e-34
kappa = 1
kB = 1.380662e-23
#kB = 8.314/6.022e23
R = 8.314
deltaHact_f = HTS - HR
deltaHact_b = HTS - HP
deltaSact_f = STS - SR
deltaSact_b = STS - SPc
deltaGact_f = (deltaHact_f*1000 - Temp*deltaSact_f)*4.184
deltaGact_b = (deltaHact_b*1000 - Temp*deltaSact_b)*4.184
k_forward = kappa * kB * Temp * (1/h) * EXP(-deltaGact_f/(R * Temp))
k_backward = kappa * kB * Temp * (1/h) * EXP(-deltaGact_b/(R * Temp))

OPEN "A", #20, "/data/data/cz.p/files/thermo_s_RATES_f.txt"
PRINT #20, " "+STR$(k_forward)+" "+CHR$(042)+" TIME ; 200 SAVE moles ; -end"
CLOSE #20

OPEN "A", #10, "/data/data/cz.p/files/thermo_s_RATES_b.txt"
PRINT #10, " "+STR$(k_backward)+" "+CHR$(042)+" TIME ; 200 SAVE moles ; -end"
CLOSE #10


EXIT
END

CLS

OPEN "I", #2, "/data/data/cz.p/files/GCM1Kin.inp"
INPUT #2, Cation$, Anion$, Dist, Title1$, Title2$
CLOSE #2

OPEN "I", #3, "/data/data/cz.p/files/GCM1Kin.par"
INPUT #3, a, b, c, d, e
CLOSE #3

SeekCation% = INSTR(Cation$, "+")
SeekAnion% = INSTR(Anion$, "-")
LengthCation% = LEN(Cation$)
LengthAnion% = LEN(Anion$)
CatWord$ = LEFTOF$(Cation$, "+")
AnWord$ = LEFTOF$(Anion$, "-")
IF SeekCation% = LengthCation% THEN
zCat = 1
ELSE IF SeekCation% < LengthCation% THEN
zCat$ = MID$(Cation$, SeekCation%+1, LengthCation%-SeekCation%)
zCat = VAL(zCat$)
ENDIF
IF SeekAnion% = LengthAnion% THEN
zAn = -1
ELSE IF SeekAnion% < LengthAnion% THEN
zAn$ = MID$(Anion$, SeekAnion%+1, LengthAnion%-SeekAnion%)
zAn = -VAL(zAn$)
ELSE IF SeekAnion% = 0 THEN
z = 0
ENDIF

DIM TabulatedData$(200)

OPEN "I", #4, "/data/data/cz.p/files/GCM1Kin.dat"

FOR I% = 0 TO 199

INPUT #4, LineText$
TabulatedData$(I%) = LineText$
DataLen% = LEN(LineText$)
Del1% = INSTR(LineText$, ";")
Del2% = INSTR(LineText$, ";", Del1%+1)

Species$ = MID$(LineText$, 1, Del1%-1)
Diffusion$ = MID$(LineText$, Del1%+1, Del2%-Del1%-1)
Diffusion = VAL(Diffusion$)
Kielland$ = MID$(LineText$, Del2%+1, DataLen%-Del2%)
Kielland = VAL(Kielland$)

IF Species$ = Cation$ THEN
Diff1 = Diffusion
a1 = Kielland*1e-7
ENDIF

IF Species$ = Anion$ THEN
Diff2 = Diffusion
a2 = Kielland*1e-7
ENDIF

EXIT IF Species$ = ""
NEXT I%

CLOSE #4

IF Dist = 0 THEN
Distance = a1+a2
ELSE IF Dist > 0 THEN
Distance = Dist*1e-10
ENDIF

Theta = SQRT((8*PI*6.022e23*(4.80e-10)^2*b)/(e*c*1.38e-16*d))
Ua = (zCat*ZAn*(4.80e-10)^2/(Distance*c)) - (zCat*zAn*(4.80e-10)^2*Theta/(c*(1+Distance*Theta)))
k1 = (4*PI*1e-3*6.022e23*(Diff1+Diff2)*Distance*Ua) / (1.38e-16*d*(EXP(Ua / (1.38e-16*d))-1))
Kos = (4*PI*6.022e23*(Distance)^3/a) * EXP(-Ua / (1.38e-16*d))
k_1 = k1/Kos

! k_1 = (3*(Diff1+Diff2)*Ua) / (1.38e-16*d*(EXP(Ua / (1.38e-16*d))-1)*Distance^2) * (EXP(Ua / 1.38e-16*d))
! Kos = k1/k_1

log_k = LOG10(Kos)

IF INSTR(Cation$, "+") > 0 THEN
SignA$ = MID$(Cation$, INSTR(Cation$, "+"), LEN(Cation$)-INSTR(Cation$, "+")+1)
ELSE IF INSTR(Cation$, "-") > 0 THEN
SignA$ = MID$(Cation$, INSTR(Cation$, "-"), LEN(Cation$)-INSTR(Cation$, "-")+1)
ELSE
SignA$ = ""
ENDIF

IF INSTR(Anion$, "+") > 0 THEN
SignB$ = MID$(Anion$, INSTR(Anion$, "+"), LEN(Anion$)-INSTR(Anion$, "+")+1)
ELSE IF INSTR(Anion$, "-") > 0 THEN
SignB$ = MID$(Anion$, INSTR(Anion$, "-"), LEN(Anion$)-INSTR(Anion$, "-")+1)
ELSE
SignB$ = ""
ENDIF

IF SignA$ = "+" THEN
SignA = 1
ELSE IF SignA$ = "-" THEN
SignA = -1
ELSE
SignA = VAL(SignA$)
ENDIF

IF SignB$ = "+" THEN
SignB = 1
ELSE IF SignB$ = "-" THEN
SignB = -1
ELSE
SignB = VAL(SignB$)
ENDIF

SignC = SignA+SignB
IF SignC = 0 THEN
SignC$ = ""
ELSE IF SignC = 1 THEN
SignC$ = "+"
ELSE IF SignC > 1 THEN
SignC$ = "+"+Str$(SignC)
ELSE IF SignC = -1 THEN
SignC$ = "-"
ELSE IF SignC < -1 THEN
SignC$ = Str$(SignC)
ENDIF

C$ = CatWord$+AnWord$+SignC$

OPEN "A", #1, "/data/data/cz.p/files/GCM1Kin_Rf.out"
PRINT #1, Title1$;
PRINT #1, " ; -start";
PRINT #1, " ; 10 if (MOL("+CHR$(34)+"["+Cation$+"]"+SignA$+CHR$(34)+") <= 1e-15) then goto 200";
PRINT #1, " ; 20 if (MOL("+CHR$(34)+"["+Anion$+"]"+SignB$+CHR$(34)+") <= 1e-15) then goto 200";
PRINT #1, " ; 100 moles = "+STR$(k1)+" * MOL("+CHR$(34)+"["+Cation$+"]"+SignA$+CHR$(34)+") * MOL("+CHR$(34)+"["+Anion$+"]"+SignB$+CHR$(34)+")";
PRINT #1, " ; 200 SAVE moles";
PRINT #1, " ; -end"
CLOSE #1

OPEN "A", #10, "/data/data/cz.p/files/GCM1Kin_Kf.out"
PRINT #10, Title1$;
PRINT #10, " ; -formula ["+Cation$+"]"+SignA$+" -1 ["+Anion$+"]"+SignB$+" -1 ["+C$+"]"+SignC$+" 1"
CLOSE #10

OPEN "A", #11, "/data/data/cz.p/files/GCM1Kin_Rb.out"
PRINT #11, Title2$;
PRINT #11, " ; -start";
PRINT #11, " ; 10 if (MOL("+CHR$(34)+"["+C$+"]"+SignC$+CHR$(34)+") <= 1e-15) then goto 200";
PRINT #11, " ; 100 moles = "+STR$(k_1)+" * MOL("+CHR$(34)+"["+C$+"]"+SignC$+CHR$(34)+")";
PRINT #11, " ; 200 SAVE moles";
PRINT #11, " ; -end"
CLOSE #11

OPEN "A", #12, "/data/data/cz.p/files/GCM1Kin_Kb.out"
PRINT #12, Title2$;
PRINT #12, " ; -formula ["+Cation$+"]"+SignA$+" 1 ["+Anion$+"]"+SignB$+" 1 ["+C$+"]"+SignC$+" -1"
CLOSE #12

OPEN "A", #13, "/data/data/cz.p/files/GCM1Kin_SMS.out"
PRINT #13, "["+Cation$+"]", "["+Cation$+"]"+SignA$, "0", "["+Cation$+"]", 1
PRINT #13, "["+Anion$+"]", "["+Anion$+"]"+SignB$, "0", "["+Anion$+"]", 1
PRINT #13, "["+C$+"]", "["+C$+"]"+SignC$, "0", "["+C$+"]", 1
CLOSE #13

OPEN "A", #14, "/data/data/cz.p/files/GCM1Kin_SS.out"
PRINT #14, "["+Cation$+"]"+SignA$;" = ";"["+Cation$+"]"+SignA$
PRINT #14, "["+Anion$+"]"+SignB$;" = ";"["+Anion$+"]"+SignB$
PRINT #14, "["+C$+"]"+SignC$;" = ";"["+C$+"]"+SignC$
CLOSE #14

EXIT

END

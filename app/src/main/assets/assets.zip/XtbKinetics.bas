OPEN "O", #7, "/data/data/cz.p/files/thermo_s_SMS.txt"
CLOSE #7
OPEN "A", #7, "/data/data/cz.p/files/thermo_s_SMS.txt"

OPEN "O", #8, "/data/data/cz.p/files/thermo_s_SS.txt"
CLOSE #8
OPEN "A", #8, "/data/data/cz.p/files/thermo_s_SS.txt"

OPEN "O", #98, "/data/data/cz.p/files/thermo_s_KINETICS_f.txt"
CLOSE #98
OPEN "A", #98, "/data/data/cz.p/files/thermo_s_KINETICS_f.txt"

OPEN "O", #99, "/data/data/cz.p/files/thermo_s_KINETICS_b.txt"
CLOSE #99
OPEN "A", #99, "/data/data/cz.p/files/thermo_s_KINETICS_b.txt"

OPEN "O", #10, "/data/data/cz.p/files/thermo_s_RATES.txt"
CLOSE #10
OPEN "A", #10, "/data/data/cz.p/files/thermo_s_RATES.txt"

OPEN "I", #11, "/data/data/cz.p/files/dataset-name.txt"

DIM Inp0$(10001)
barrier_f_stored = 1e10
barrier_b_stored = 1e10
Prev = 0
PrevPrev = 0
PrevPrevPrev = 0
PrevPrevPrevPrev = 0

OPEN "I", #1, "/data/data/cz.p/files/XtbKin.out"

K% = 0

DO

EXIT IF (K% = 10000 OR PrevPrevPrevPrev = 1)

INPUT #1, LineOutput$
LineOutput$ = TRIM$(LineOutput$)

Inp0$(K%) = LineOutput$

LenghtLine% = LEN(LineOutput$)

IF (LineOutput$ = "" AND Prev = 1 AND PrevPrev = 1 AND PrevPrevPrev = 1) THEN
PrevPrevPrevPrev = 1
ENDIF

IF (LineOutput$ = "" AND Prev = 1 AND PrevPrev = 1) THEN
PrevPrevPrev = 1
ENDIF

IF (LineOutput$ = "" AND Prev = 1) THEN
PrevPrev = 1
ENDIF

IF LineOutput$ = "" THEN
Prev = 1
ELSE
Prev = 0
PrevPrev = 0
PrevPrevPrev = 0
PrevPrevPrevPrev = 0
ENDIF

IF TALLY(LineOutput$, "forward") > 0 THEN
pos_sep = INSTR(LineOutput$,":")
barrier_f = VAL(MID$(LineOutput$, pos_sep+1, LenghtLine%-pos_sep-1))
IF barrier_f < barrier_f_stored THEN
barrier_f_stored = barrier_f
ENDIF
ENDIF

IF TALLY(LineOutput$, "backward") > 0 THEN
pos_sep = INSTR(LineOutput$,":")
barrier_b = VAL(MID$(LineOutput$, pos_sep+1, LenghtLine%-pos_sep-1))
IF barrier_b < barrier_b_stored THEN
barrier_b_stored = barrier_b
ENDIF
ENDIF

K% = K% + 1

LOOP

CLOSE #1

OPEN "I", #6, "/data/data/cz.p/files/temperature.txt"
INPUT #6, Temp$
Temp = VAL(Temp$)
CLOSE #6

h = 6.626176e-34
kappa = 1
kB = 1.380662e-23
#kB = 8.314/6.022e23
R = 8.314
deltaGact_f = barrier_f_stored*4.184*1000
deltaGact_b = barrier_b_stored*4.184*1000
k_forward = kappa * kB * Temp * (1/h) * EXP(-deltaGact_f/(R * Temp))
k_backward = kappa * kB * Temp * (1/h) * EXP(-deltaGact_b/(R * Temp))

INPUT #11, DatasetName$

PRINT #98, DatasetName$;"_forward ; -formula ";
PRINT #99, DatasetName$;"_backward ; -formula ";
PRINT #10, DatasetName$;"_forward ; -start ; 100 moles = "+STR$(k_forward)+" "+CHR$(042);

DIM Inp$(10001)

OPEN "I", #21, "/data/data/cz.p/files/Xtb_formulaR.txt"

I% = 0

DO

INPUT #21, FormulaR1$

Inp$(I%) = FormulaR1$

EXIT IF (I% = 10000 OR FormulaR1$ = "")

IF TALLY(FormulaR1$,"+")>0 THEN
LenR1% = LEN(FormulaR1$)
PosR1% = INSTR(FormulaR1$, "+")
ChargeCharacterR1$ = MID$(FormulaR1$, PosR1%, LenR1%-PosR1%+1)
SMS_R1$ = CHR$(091)+FormulaR1$+CHR$(093)
FormulaR1$ = CHR$(091)+FormulaR1$+CHR$(093)+ChargeCharacterR1$
ELSE IF TALLY(FormulaR1$,"-")>0 THEN
LenR1% = LEN(FormulaR1$)
PosR1% = INSTR(FormulaR1$, "-")
ChargeCharacterR1$ = MID$(FormulaR1$, PosR1%, LenR1%-PosR1%+1)
SMS_R1$ = CHR$(091)+FormulaR1$+CHR$(093)
FormulaR1$ = CHR$(091)+FormulaR1$+CHR$(093)+ChargeCharacterR1$
ELSE
SMS_R1$ = CHR$(091)+FormulaR1$+CHR$(093)
FormulaR1$ = CHR$(091)+FormulaR1$+CHR$(093)
ENDIF

PRINT #7, SMS_R1$, FormulaR1$, "0", SMS_R1$, 1

PRINT #8, FormulaR1$;" = ";FormulaR1$

PRINT #98, FormulaR1$;" -1 ";
PRINT #99, FormulaR1$;" 1 ";

PRINT #10, " MOL("+CHR$(034)+FormulaR1$+CHR$(034)+") "+CHR$(042);

I% = I% + 1

LOOP

PRINT #10, " TIME ; 200 SAVE moles ; -end"

PRINT #10, DatasetName$;"_backward ; -start ; 100 moles = "+STR$(k_backward)+" "+CHR$(042);

DIM Inp2$(10001)

OPEN "I", #22, "/data/data/cz.p/files/Xtb_formulaP.txt"

J% = 0

DO

INPUT #22, FormulaP1$

Inp$(J%) = FormulaP1$

EXIT IF (J% = 10000 OR FormulaP1$ = "")

IF TALLY(FormulaP1$,"+")>0 THEN
LenP1% = LEN(FormulaP1$)
PosP1% = INSTR(FormulaP1$, "+")
ChargeCharacterP1$ = MID$(FormulaP1$, PosP1%, LenP1%-PosP1%+1)
SMS_P1$ = CHR$(091)+FormulaP1$+CHR$(093)
FormulaP1$ = CHR$(091)+FormulaP1$+CHR$(093)+ChargeCharacterP1$
ELSE IF TALLY(FormulaP1$,"-")>0 THEN
LenP1% = LEN(FormulaP1$)
PosP1% = INSTR(FormulaP1$, "-")
ChargeCharacterP1$ = MID$(FormulaP1$, PosP1%, LenP1%-PosP1%+1)
SMS_P1$ = CHR$(091)+FormulaP1$+CHR$(093)
FormulaP1$ = CHR$(091)+FormulaP1$+CHR$(093)+ChargeCharacterP1$
ELSE
SMS_P1$ = CHR$(091)+FormulaP1$+CHR$(093)
FormulaP1$ = CHR$(091)+FormulaP1$+CHR$(093)
ENDIF

PRINT #7, SMS_P1$, FormulaP1$, "0", SMS_P1$, 1

PRINT #8, FormulaP1$;" = ";FormulaP1$

PRINT #98, FormulaP1$;" 1 ";
PRINT #99, FormulaP1$;" -1 ";

PRINT #10, " MOL("+CHR$(034)+FormulaP1$+CHR$(034)+") "+CHR$(042);

J% = J% + 1

LOOP

PRINT #10, " TIME ; 200 SAVE moles ; -end"

CLOSE #98
CLOSE #99

#####################################
####### COCATENATE FILES ############
#####################################

OPEN "O", #9, "/data/data/cz.p/files/thermo_s_KINETICS.txt"
CLOSE #9

OPEN "I", #98, "/data/data/cz.p/files/thermo_s_KINETICS_f.txt"
OPEN "I", #99, "/data/data/cz.p/files/thermo_s_KINETICS_b.txt"

OPEN "A", #9, "/data/data/cz.p/files/thermo_s_KINETICS.txt"

DIM ArrayF$(10001)
DIM ArrayB$(10001)

L% = 0

DO
INPUT #98, LineF$
ArrayF$(L%) = LineF$
EXIT IF (L% = 10000 OR LineF$ = "")
PRINT #9, LineF$
L% = L% + 1
LOOP

M% = 0

DO
INPUT #99, LineB$
ArrayB$(M%) = LineB$
EXIT IF (M% = 10000 OR LineB$ = "")
PRINT #9, LineB$
M% = M% + 1
LOOP

CLOSE #98
CLOSE #99
CLOSE #9

EXIT
END

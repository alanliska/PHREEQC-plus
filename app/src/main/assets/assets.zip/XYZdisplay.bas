
OPEN "O", #1, "/data/data/cz.p/files/XYZ_view.csv"
CLOSE #1
OPEN "A", #1, "/data/data/cz.p/files/XYZ_view.csv"


OPEN "I", #2, "/data/data/cz.p/files/XYZ_view.xyz"

OPEN "O", #3, "/data/data/cz.p/files/XYZ_view2.xyz"
CLOSE #3
OPEN "A", #3, "/data/data/cz.p/files/XYZ_view2.xyz"

DIM Xyz$(10001)

# plane XY ... z=0
A = 0
B = 0
C = 1
D = 0

K% = 0

DO

INPUT #2, LineXyz$
LineXyz$ = TRIM$(LineXyz$)
Xyz$(K%) = LineXyz$

Element$ = ""
X$ = ""
Y$ = ""
Z$ = ""

IF K% < 2 THEN
PRINT #3, LineXyz$
GOTO Skip
ENDIF

J% = 1
WHILE LEN(LineXyz$)
SPLIT LineXyz$," ",0,a$,LineXyz$
IF J% = 1 THEN
Element$ = a$
ELSE IF J% = 2 THEN
X$ = a$
X = VAL(X$)
ELSE IF J% = 3 THEN
Y$ = a$
Y = VAL(Y$)
ELSE IF J% = 4 THEN
Z$ = a$
Z = VAL(Z$)
ENDIF
INC J%
WEND

X_new = X
Y_new = Y
Z_new = Z

X_proj = X_new - A*(X_new * A + Y_new * B + Z_new * C)/(A^2+B^2+C^2)
Y_proj = Y_new - B*(X_new * A + Y_new * B + Z_new * C)/(A^2+B^2+C^2)
Z_proj = Z_new - C*(X_new * A + Y_new * B + Z_new * C)/(A^2+B^2+C^2)


EXIT IF (K% = 10000 OR Element$ = "")
PRINT #1, X_proj;",";Y_proj
PRINT #3, Element$, X_new, Y_new, Z_new

Skip:
K% = K% + 1

LOOP


CLOSE #1
CLOSE #2
CLOSE #3
EXIT
END

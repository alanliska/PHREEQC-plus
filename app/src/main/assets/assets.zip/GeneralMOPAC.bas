CLS

H = 0
S = 0
SR = 0
HR = 0
SPc = 0
# manual: The variable SP represents the internal X11-Basic stack pointer. Do not name any other variable SP (or PC) since no value can be assigned to it.
HP = 0

OPEN "I", #1, "/data/data/cz.p/files/thermo_s_General.txt"
INPUT #1, Thermo$
LenghtData% = LEN(Thermo$)
Lim0% = INSTR(Thermo$, " ")
Name$ = MID$(Thermo$, 1, Lim0%-1)
Lim1% = INSTR(Thermo$, " ", Lim0%+1)
Formula$ = MID$(Thermo$, Lim0%+1, Lim1%-Lim0%-1)
Lim2% = INSTR(Thermo$, " ", Lim1%+1)
Method$ = MID$(Thermo$, Lim1%+1, Lim2%-Lim1%-1)
Lim3% = INSTR(Thermo$, " ", Lim2%+1)
TotDummy$ = MID$(Thermo$, Lim2%+1, Lim3%-Lim2%-1)
Lim4% = INSTR(Thermo$, " ", Lim3%+1)
H$ = MID$(Thermo$, Lim3%+1, Lim4%-Lim3%-1)
Lim5% = INSTR(Thermo$, " ", Lim4%+1)
Dummy1$ = MID$(Thermo$, Lim4%+1, Lim5%-Lim4%-1)
Lim6% = INSTR(Thermo$, " ", Lim5%+1)
Dummy2$ = MID$(Thermo$, Lim5%+1, Lim6%-Lim5%-1)
Lim7% = INSTR(Thermo$, " ", Lim6%+1)
S$ = MID$(Thermo$, Lim6%+1, LenghtData%-Lim7%)
S = VAL(S$)
H = VAL(H$)

IF TALLY(Formula$,"+")>0 THEN
Len% = LEN(Formula$)
Pos% = INSTR(Formula$, "+")
ChargeCharacter$ = MID$(Formula$, Pos%, Len%-Pos%+1)
SMS$ = CHR$(091)+Formula$+CHR$(093)
Formula$ = CHR$(091)+Formula$+CHR$(093)+ChargeCharacter$
ELSE IF TALLY(Formula$,"-")>0 THEN
Len% = LEN(Formula$)
Pos% = INSTR(Formula$, "-")
ChargeCharacter$ = MID$(Formula$, Pos%, Len%-Pos%+1)
SMS$ = CHR$(091)+Formula$+CHR$(093)
Formula$ = CHR$(091)+Formula$+CHR$(093)+ChargeCharacter$
ELSE
SMS$ = CHR$(091)+Formula$+CHR$(093)
Formula$ = CHR$(091)+Formula$+CHR$(093)
ENDIF

CLOSE #1

OPEN "I", #2, "/data/data/cz.p/files/GeneralStatus.txt"
INPUT #2, Status$
CLOSE #2

IF Status$ = "Product" THEN

IF EXIST("/data/data/cz.p/files/GeneralResults_P.txt") = -1 THEN
OPEN "I", #3, "/data/data/cz.p/files/GeneralResults_P.txt"
INPUT #3, ThermoP$
LenghtDataP% = LEN(ThermoP$)
Lim0% = INSTR(ThermoP$, " ")
NameP$ = MID$(ThermoP$, 1, Lim0%-1)
Lim1% = INSTR(ThermoP$, " ", Lim0%+1)
FormulaP$ = MID$(ThermoP$, Lim0%+1, Lim1%-Lim0%-1)
Lim2% = INSTR(ThermoP$, " ", Lim1%+1)
MethodP$ = MID$(ThermoP$, Lim1%+1, Lim2%-Lim1%-1)
Lim3% = INSTR(ThermoP$, " ", Lim2%+1)
TotDummyP$ = MID$(ThermoP$, Lim2%+1, Lim3%-Lim2%-1)
Lim4% = INSTR(ThermoP$, " ", Lim3%+1)
HP$ = MID$(ThermoP$, Lim3%+1, Lim4%-Lim3%-1)
Lim5% = INSTR(ThermoP$, " ", Lim4%+1)
Dummy1P$ = MID$(ThermoP$, Lim4%+1, Lim5%-Lim4%-1)
Lim6% = INSTR(ThermoP$, " ", Lim5%+1)
Dummy2P$ = MID$(ThermoP$, Lim5%+1, Lim6%-Lim5%-1)
Lim7% = INSTR(ThermoP$, " ", Lim6%+1)
SPc$ = MID$(ThermoP$, Lim6%+1, LenghtDataP%-Lim7%)
SPc = VAL(SPc$)
HP = VAL(HP$)
CLOSE #3

ENDIF

ELSE IF Status$ = "Reactant" THEN

IF EXIST("/data/data/cz.p/files/GeneralResults_R.txt") = -1 THEN
OPEN "I", #4, "/data/data/cz.p/files/GeneralResults_R.txt"
INPUT #4, ThermoR$
LenghtDataR% = LEN(ThermoR$)
Lim0% = INSTR(ThermoR$, " ")
NameR$ = MID$(ThermoR$, 1, Lim0%-1)
Lim1% = INSTR(ThermoR$, " ", Lim0%+1)
FormulaR$ = MID$(ThermoR$, Lim0%+1, Lim1%-Lim0%-1)
Lim2% = INSTR(ThermoR$, " ", Lim1%+1)
MethodR$ = MID$(ThermoR$, Lim1%+1, Lim2%-Lim1%-1)
Lim3% = INSTR(ThermoR$, " ", Lim2%+1)
TotDummyR$ = MID$(ThermoR$, Lim2%+1, Lim3%-Lim2%-1)
Lim4% = INSTR(ThermoR$, " ", Lim3%+1)
HR$ = MID$(ThermoR$, Lim3%+1, Lim4%-Lim3%-1)
Lim5% = INSTR(ThermoR$, " ", Lim4%+1)
Dummy1R$ = MID$(ThermoR$, Lim4%+1, Lim5%-Lim4%-1)
Lim6% = INSTR(ThermoR$, " ", Lim5%+1)
Dummy2R$ = MID$(ThermoR$, Lim5%+1, Lim6%-Lim5%-1)
Lim7% = INSTR(ThermoR$, " ", Lim6%+1)
SR$ = MID$(ThermoR$, Lim6%+1, LenghtDataR%-Lim7%)
SR = VAL(SR$)
HR = VAL(HR$)
CLOSE #4

ENDIF

ENDIF

IF Status$ = "Product" THEN
H = H + HP
S = S + SPc
ELSE IF Status$ = "Reactant" THEN
H = H + HR
S = S + SR
ENDIF

IF Status$ = "Product" THEN

OPEN "O", #5, "/data/data/cz.p/files/GeneralResults_P.txt"
PRINT #5, "Name Formula Method TOT ";H;" Dummy Dummy ";S
CLOSE #5

ELSE IF Status$ = "Reactant" THEN

OPEN "O", #6, "/data/data/cz.p/files/GeneralResults_R.txt"
PRINT #6, "Name Formula Method TOT ";H;" Dummy Dummy ";S
CLOSE #6

ENDIF

OPEN "A", #7, "/data/data/cz.p/files/thermo_s_SMS.txt"
PRINT #7, SMS$, Formula$, "0", SMS$, "1"
CLOSE #7

OPEN "A", #8, "/data/data/cz.p/files/thermo_s_SS.txt"
PRINT #8, Formula$;" = ";Formula$
CLOSE #8

OPEN "A", #9, "/data/data/cz.p/files/thermo_s_KINETICS_f.txt"
IF Status$ = "Product" THEN
PRINT #9, Formula$;" 1 ";
ELSE IF Status$ = "Reactant" THEN
PRINT #9, Formula$;" -1 ";
ENDIF
CLOSE #9

OPEN "A", #10, "/data/data/cz.p/files/thermo_s_KINETICS_b.txt"
IF Status$ = "Product" THEN
PRINT #10, Formula$;" -1 ";
ELSE IF Status$ = "Reactant" THEN
PRINT #10, Formula$;" 1 ";
ENDIF
CLOSE #10

IF Status$ = "Reactant" THEN
OPEN "A", #11, "/data/data/cz.p/files/thermo_s_RATES_f.txt"
PRINT #11, " MOL("+CHR$(034)+Formula$+CHR$(034)+") "+CHR$(042);
CLOSE #11
ENDIF

IF Status$ = "Product" THEN
OPEN "A", #12, "/data/data/cz.p/files/thermo_s_RATES_b.txt"
PRINT #12, " MOL("+CHR$(034)+Formula$+CHR$(034)+") "+CHR$(042);
CLOSE #12
ENDIF

EXIT
END

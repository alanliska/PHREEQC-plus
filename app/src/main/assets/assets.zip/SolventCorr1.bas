OPEN "I", #1, "/data/data/cz.p/files/SolventFragment.txt"
OPEN "O", #2, "/data/data/cz.p/files/SolventCorr_logk.txt"
OPEN "O", #3, "/data/data/cz.p/files/SolventCorr_deltah.txt"

INPUT #1, SolventLine$

SolventLine$ = TRIM$(SolventLine$)
Lim0% = INSTR(SolventLine$, ";")
Lim1% = INSTR(SolventLine$, ";", Lim0%+1)
LogK$ = MID$(SolventLine$, Lim0%+8, Lim1%-Lim0%-8)
Lim2% = INSTR(SolventLine$, ";", Lim1%+10)

DeltaH$ = MID$(SolventLine$, Lim1%+10, Lim2%-Lim1%-10)

LogK = VAL(LogK$)

DeltaH = VAL(DeltaH$)
#print SolventLine$
#print LogK$
#print LogK
#print DeltaH$
#print DeltaH

PRINT #2, LogK
PRINT #3, DeltaH

CLOSE #1
CLOSE #2
CLOSE #3

END

EXIT


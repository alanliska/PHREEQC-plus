CLS

DIM Dat$(200)
DIM Inp$(101)

# units = kJ.mol-1
Cum_H = 68.29
Cum_G = 53.88
Cum_Tb = 198.2
Cum_Tf = 122.5
Cum_Cp_a = 0
Cum_Cp_b = 0
Cum_Cp_c = 0
Cum_Cp_d = 0
Cum_Cp = 0

Cum_NA = 0

OPEN "I", #10, "/data/data/cz.p/files/iupac.txt"
INPUT #10, Iupac$
CLOSE #10

OPEN "I", #11, "/data/data/cz.p/files/gcm2formula.txt"
INPUT #11, Formula$
CLOSE #11

OPEN "I", #1, "/data/data/cz.p/files/GCM2.dat"





I% = 0

DO

INPUT #1, Item$

Lenght% = LEN(Item$)
Dat$(I%) = Item$
Delim1% = INSTR(Item$, ";")
Symbol$ = MID$(Item$, 1, Delim1%-1)
# here:
Delim2% = INSTR(Item$, ";", Delim1%+1)
#
H$ = MID$(Item$, Delim1%+1, Delim2%-Delim1%-1)
H = VAL(H$)
# Delim2% = INSTR(Item$, ";", Delim1%+1) !!! not here, but up - otherwise does not work at all !!!
Delim3% = INSTR(Item$, ";", Delim2%+1)
G$ = MID$(Item$, Delim2%+1, Delim3%-Delim2%-1)
G = VAL(G$)
Delim4% = INSTR(Item$, ";", Delim3%+1)
Tb$ = MID$(Item$, Delim3%+1, Delim4%-Delim3%-1)
Tb = VAL(Tb$)
Delim5% = INSTR(Item$, ";", Delim4%+1)
Tf$ = MID$(Item$, Delim4%+1, Delim5%-Delim4%-1)
Tf = VAL(Tf$)
Delim6% = INSTR(Item$, ";", Delim5%+1)
Cp_a$ = MID$(Item$, Delim5%+1, Delim6%-Delim5%-1)
Cp_a = VAL(Cp_a$)
Delim7% = INSTR(Item$, ";", Delim6%+1)
Cp_b$ = MID$(Item$, Delim6%+1, Delim7%-Delim6%-1)
Cp_b = VAL(Cp_b$)
Delim8% = INSTR(Item$, ";", Delim7%+1)
Cp_c$ = MID$(Item$, Delim7%+1, Delim8%-Delim7%-1)
Cp_c = VAL(Cp_c$)
Cp_d$ = MID$(Item$, Delim8%+1, Lenght%-Delim8%)
Cp_d = VAL(Cp_d$)


J% = 0

OPEN "I", #3, "/data/data/cz.p/files/GCM2-input.txt"

DO

INPUT #3, Request$

Inp$(J%) = Request$
LenghtReq% = LEN(Request$)
Lim% = INSTR(Request$, ";")
Atom$ = LEFT$(Request$, Lim%-1)
Count$ = MID$(Request$, Lim%+1, LenghtReq%)

IF (Symbol$ = Atom$ OR Atom$ = Symbol$) AND (Symbol$ <> "" OR Atom$ <> "") THEN 
Stoich$ = Count$

Cum_H = Cum_H + H * VAL(Stoich$)
Cum_G = Cum_G + G * VAL(Stoich$)
Cum_Tb = Cum_Tb + Tb * VAL(Stoich$)
Cum_Tf = Cum_Tf + Tf * VAL(Stoich$)
Cum_Cp_a = Cum_Cp_a + Cp_a * VAL(Stoich$)
Cum_Cp_b = Cum_Cp_b + Cp_b * VAL(Stoich$)
Cum_Cp_c = Cum_Cp_c + Cp_c * VAL(Stoich$)
Cum_Cp_d = Cum_Cp_d + Cp_d * VAL(Stoich$)
Cum_NA = Cum_NA + VAL(Stoich$)

ENDIF

J% = J% + 1
EXIT IF (J% = 100 OR Atom$ = "")
LOOP

CLOSE #3

I% = I% + 1

EXIT IF (I% = 200 OR Symbol$ = "")

LOOP

CLOSE #1

Cum_Cp = Cum_Cp_a - 37.93 + (Cum_Cp_b + 0.210)*298.15 + (Cum_Cp_c - 3.91e-4)*(298.15)^2 + (Cum_Cp_d + 2.06e-7)*(298.15)^3


OPEN "A", #2, "/data/data/cz.p/files/GCM2.out"
PRINT #2, Iupac$;" ";Formula$;" ";"GCM-Joback-Reid";" ";Cum_G;" ";Cum_H;" ";Cum_Cp;" ";Cum_Tf;" ";Cum_Tb
CLOSE #2
EXIT
END

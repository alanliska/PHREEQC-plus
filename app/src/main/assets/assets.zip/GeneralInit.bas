CLS

OPEN "I", #11, "/data/data/cz.p/files/dataset-name.txt"
INPUT #11, DatasetName$
CLOSE #11

OPEN "A", #19, "/data/data/cz.p/files/thermo_s_KINETICS_f.txt"
PRINT #19, DatasetName$;"_forward ; -formula ";
CLOSE #19

OPEN "A", #9, "/data/data/cz.p/files/thermo_s_KINETICS_b.txt"
PRINT #9, DatasetName$;"_backward ; -formula ";
CLOSE #9

OPEN "A", #20, "/data/data/cz.p/files/thermo_s_RATES_f.txt"
PRINT #20, DatasetName$;"_forward ; -start ; 100 moles = ";
CLOSE #20

OPEN "A", #10, "/data/data/cz.p/files/thermo_s_RATES_b.txt"
PRINT #10, DatasetName$;"_backward ; -start ; 100 moles = ";
CLOSE #10

EXIT
END

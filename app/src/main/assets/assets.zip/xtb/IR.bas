# set the normalization factor for Gaussian function
M = 0
# set the normalization factor for Lorentzian function
N = 1
# eps - max absorpt. wavelength
# x - data point
# sigma - full width at half maximum of the electronic transition / eV
sigma = 0.01

# absorbance
#PseudoVoigt = N*((1-M)*EXP(-((Energy-eps)/sigma)^2)+M/(1+4*((Energy-eps)/sigma)^2))

DIM Inp$(1000)
OPEN "O", #2, "/data/data/cz.p/files/xtb/graph-series1.csv"
CLOSE #2


ny = -100
DO

#Energy = (6.62607015e-34*299792458/(lambda*1e-9))/1.602176634e-19
Energy = 1.2398e-4 * ny
#print "Energy=";Energy
Absorbance = 0





I% = 0
OPEN "I", #1, "/data/data/cz.p/files/xtb/vib5.txt"
DO
#print I%

INPUT #1, LineData$
Inp$(I%) = LineData$

Comma = INSTR(LineData$,";")
Length = LEN(LineData$)
w$ = MID$(LineData$, 1, Comma-1)
eps = 1.2398e-4*VAL(w$)

OscS$ = MID$(LineData$, Comma+1, Length-Comma)
OscS = VAL(OscS$)

Absorbance = Absorbance + M*OscS*EXP(-((Energy-eps)/sigma)^2) + N*0.5*sigma*OscS/(PI*(eps-Energy)^2+0.25*sigma^2)

Transmitance = 10^(-0.00001*Absorbance) * 100

INC I%
EXIT IF LineData$ = ""
LOOP

CLOSE #1

OPEN "A", #2, "/data/data/cz.p/files/xtb/graph-series1.csv"
#PRINT ny;",";Transmitance

PRINT #2, ny;",";Transmitance

CLOSE #2
ny = ny + 1
EXIT IF ny > 4000
#EXIT IF LineData$ = ""
LOOP



END

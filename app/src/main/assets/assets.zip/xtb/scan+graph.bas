
OPEN "O", #1, "Energy-xtb.txt"
CLOSE #1

OPEN "I", #3, "Energy-shift.txt"
INPUT #3, shift$
shift = VAL(shift$)
CLOSE #3

DIM Inp$(5000)
OPEN "I", #2, "Output2-xtb.txt"

I% = 0
DO

INPUT #2, LineData$
Inp$(I%) = LineData$

energy_h$ = ""

FormattedLineData$ = XTRIM$(LineData$)
J% = 1
WHILE LEN(FormattedLineData$)
SPLIT FormattedLineData$," ",0,a$,FormattedLineData$
IF J% = 3 THEN
energy_h$ = a$
ENDIF
INC J%
WEND

I% = I% + 1
EXIT IF (I% = 4999 OR energy_h$ = "")

energy_h = 2625.5*VAL(energy_h$)
energy_shifted = energy_h+shift

OPEN "A", #1, "Energy-xtb.txt"
PRINT #1, energy_shifted
CLOSE #1

LOOP

CLOSE #2

EXIT

END

OPEN "O", #1, "uv5.txt"
CLOSE #1

DIM Inp$(5000)
OPEN "I", #2, "uv4.txt"

I% = 0
DO

INPUT #2, LineData$
Inp$(I%) = LineData$

nm$ = ""

FormattedLineData$ = XTRIM$(LineData$)
J% = 1
WHILE LEN(FormattedLineData$)
SPLIT FormattedLineData$," ",0,a$,FormattedLineData$
IF J% = 3 THEN
nm$ = a$
ELSE IF J% = 4 THEN
os$ = a$
ENDIF
INC J%
WEND

I% = I% + 1
EXIT IF (I% = 4999 OR nm$ = "")

OPEN "A", #1, "uv5.txt"
PRINT #1, nm$+" "+os$
CLOSE #1

LOOP

CLOSE #2

EXIT

END
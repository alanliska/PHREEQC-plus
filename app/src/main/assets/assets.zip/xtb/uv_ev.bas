
OPEN "O", #1, "uv2.txt"
CLOSE #1

DIM Inp$(5000)
OPEN "I", #2, "uv1.txt"

I% = 0
DO

INPUT #2, LineData$
Inp$(I%) = LineData$

ev$ = ""

FormattedLineData$ = XTRIM$(LineData$)
J% = 1
WHILE LEN(FormattedLineData$)
SPLIT FormattedLineData$," ",0,a$,FormattedLineData$
IF J% = 2 THEN
ev$ = a$
ELSE IF J% = 3 THEN
os$ = a$
ENDIF
INC J%
WEND

I% = I% + 1
EXIT IF (I% = 4999 OR ev$ = "")

OPEN "A", #1, "uv2.txt"
PRINT #1, ev$+" "+os$
CLOSE #1

LOOP

CLOSE #2

EXIT

END
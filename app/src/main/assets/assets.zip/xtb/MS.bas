DIM Inp$(1000)
OPEN "O", #2, "/data/data/cz.p/files/xtb/graph-series1.csv"
CLOSE #2




I% = 0
OPEN "I", #1, "/data/data/cz.p/files/xtb/ms4.txt"
DO

INPUT #1, LineData$
Inp$(I%) = LineData$

EXIT IF LineData$ = ""

Comma = INSTR(LineData$,";")
Length = LEN(LineData$)
mass$ = MID$(LineData$, 1, Comma-1)
mass = VAL(mass$)
abund$ = MID$(LineData$, Comma+1, Length-Comma)
abund = VAL(abund$)

OPEN "A", #2, "/data/data/cz.p/files/xtb/graph-series1.csv"

PRINT #2, mass-0.000001;",";0
PRINT #2, mass;",";abund
PRINT #2, mass+0.000001;",";0

CLOSE #2


INC I%

LOOP

CLOSE #1



END

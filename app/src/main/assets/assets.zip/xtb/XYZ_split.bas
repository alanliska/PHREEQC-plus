CLS

TotNumQuery = 0
EnergyQuery = 0
CoordQuery = 0

Count_e = 0
Count_H = 0
Count_D = 0
Count_Li = 0
Count_Na = 0
Count_K = 0
Count_Rb = 0
Count_Cs = 0
Count_Fr = 0
Count_Be = 0
Count_Mg = 0
Count_Ca = 0
Count_Sr = 0
Count_Ba = 0
Count_Ra = 0
Count_Sc = 0
Count_Y = 0
Count_La = 0
Count_Ac = 0
Count_Ce = 0
Count_Pr = 0
Count_Nd = 0
Count_Pm = 0
Count_Sm = 0
Count_Eu = 0
Count_Gd = 0
Count_Tb = 0
Count_Dy = 0
Count_Ho = 0
Count_Er = 0
Count_Tm = 0
Count_Yb = 0
Count_Lu = 0
Count_Th = 0
Count_Pa = 0
Count_U = 0
Count_Np = 0
Count_Pu = 0
Count_Am = 0
Count_Cm = 0
Count_Bk = 0
Count_Cf = 0
Count_Es = 0
Count_Fm = 0
Count_Md = 0
Count_No = 0
Count_Lr = 0
Count_Ti = 0
Count_Zr = 0
Count_Hf = 0
Count_Rf = 0
Count_V = 0
Count_Nb = 0
Count_Ta = 0
Count_Db = 0
Count_Cr = 0
Count_Mo = 0
Count_W = 0
Count_Sg = 0
Count_Mn = 0
Count_Tc = 0
Count_Re = 0
Count_Bh = 0
Count_Fe = 0
Count_Ru = 0
Count_Os = 0
Count_Hs = 0
Count_Co = 0
Count_Rh = 0
Count_Ir = 0
Count_Mt = 0
Count_Ni = 0
Count_Pd = 0
Count_Pt = 0
Count_Ds = 0
Count_Cu = 0
Count_Ag = 0
Count_Au = 0
Count_Rg = 0
Count_Zn = 0
Count_Cd = 0
Count_Hg = 0
Count_Cn = 0
Count_B = 0
Count_Al = 0
Count_Ga = 0
Count_In = 0
Count_Tl = 0
Count_Nh = 0
Count_C = 0
Count_Si = 0
Count_Ge = 0
Count_Sn = 0
Count_Pb = 0
Count_Fl = 0
Count_N = 0
Count_P = 0
Count_As = 0
Count_Sb = 0
Count_Bi = 0
Count_Mc = 0
Count_O = 0
Count_S = 0
Count_Se = 0
Count_Te = 0
Count_Po = 0
Count_Lv = 0
Count_F = 0
Count_Cl = 0
Count_Br = 0
Count_I = 0
Count_At = 0
Count_Ts = 0
Count_He = 0
Count_Ne = 0
Count_Ar = 0
Count_Kr = 0
Count_Xe = 0
Count_Rn = 0
Count_Og = 0

# count lines in the particular structure
K% = 0

DIM Inp$(10001)
OPEN "I", #1, "/data/data/cz.p/files/xtb/multistructure.xyz"

# count overall lines
I% = 0

# count number of individual structures
L% = 0

DO

INPUT #1, LineData$
Inp$(I%) = LineData$
LenghtData% = LEN(LineData$)

# remove excessive spaces, tabs etc.
TrimLineData$ = TRIM$(LineData$)

#print TrimLineData$

AlphabetCharOccurence = TALLY(TrimLineData$,"A")+TALLY(TrimLineData$,"B")+TALLY(TrimLineData$,"C")+TALLY(TrimLineData$,"D")+TALLY(TrimLineData$,"E")+TALLY(TrimLineData$,"F")+TALLY(TrimLineData$,"G")+TALLY(TrimLineData$,"H")+TALLY(TrimLineData$,"I")+TALLY(TrimLineData$,"J")+TALLY(TrimLineData$,"K")+TALLY(TrimLineData$,"L")+TALLY(TrimLineData$,"M")+TALLY(TrimLineData$,"N")+TALLY(TrimLineData$,"O")+TALLY(TrimLineData$,"P")+TALLY(TrimLineData$,"Q")+TALLY(TrimLineData$,"R")+TALLY(TrimLineData$,"S")+TALLY(TrimLineData$,"T")+TALLY(TrimLineData$,"U")+TALLY(TrimLineData$,"V")+TALLY(TrimLineData$,"W")+TALLY(TrimLineData$,"X")+TALLY(TrimLineData$,"Y")+TALLY(TrimLineData$,"Z")+TALLY(TrimLineData$,"a")+TALLY(TrimLineData$,"b")+TALLY(TrimLineData$,"c")+TALLY(TrimLineData$,"d")+TALLY(TrimLineData$,"e")+TALLY(TrimLineData$,"f")+TALLY(TrimLineData$,"g")+TALLY(TrimLineData$,"h")+TALLY(TrimLineData$,"i")+TALLY(TrimLineData$,"j")+TALLY(TrimLineData$,"k")+TALLY(TrimLineData$,"l")+TALLY(TrimLineData$,"m")+TALLY(TrimLineData$,"n")+TALLY(TrimLineData$,"o")+TALLY(TrimLineData$,"p")+TALLY(TrimLineData$,"q")+TALLY(TrimLineData$,"r")+TALLY(TrimLineData$,"s")+TALLY(TrimLineData$,"t")+TALLY(TrimLineData$,"u")+TALLY(TrimLineData$,"v")+TALLY(TrimLineData$,"w")+TALLY(TrimLineData$,"x")+TALLY(TrimLineData$,"y")+TALLY(TrimLineData$,"z")

DotOccurence = TALLY(TrimLineData$,".")

# check if the actual line denotes the total number of atoms
IF AlphabetCharOccurence = 0 AND DotOccurence = 0 THEN

TotNumQuery = 1
EnergyQuery = 0
CoordQuery = 0

IF L% = 0 THEN
OldTotNum = VAL(TrimLineData$)
TotNum = VAL(TrimLineData$)
ELSE
OldTotNum = TotNum
TotNum = VAL(TrimLineData$)
ENDIF

# check if the actual line contains the info on energy
ELSE IF AlphabetCharOccurence = 0 AND DotOccurence = 1 THEN

TotNumQuery = 0
EnergyQuery = 1
CoordQuery = 0
Energy = VAL(TrimLineData$)

#check if the actual line contains coordinates of an atom
ELSE IF AlphabetCharOccurence > 0 THEN

TotNumQuery = 0
EnergyQuery = 0
CoordQuery = 1
Coord$ = TrimLineData$

  J% = 0
WHILE LEN(TrimLineData$)
  SPLIT TrimLineData$," ",0,RestLineData$,TrimLineData$
  IF J% = 0 THEN
  Element$ = RestLineData$
  ENDIF
  INC J%
WEND

# update the info on element composition of the actual species

IF Element$ = "H" THEN
Count_H = Count_H + 1
ELSE IF Element$ = "D" THEN
Count_D = Count_D + 1
ELSE IF Element$ = "Li" THEN
Count_Li = Count_Li + 1
ELSE IF Element$ = "Na" THEN
Count_Na = Count_Na + 1
ELSE IF Element$ = "K" THEN
Count_K = Count_K + 1
ELSE IF Element$ = "Rb" THEN
Count_Rb = Count_Rb + 1
ELSE IF Element$ = "Cs" THEN
Count_Cs = Count_Cs + 1
ELSE IF Element$ = "Fr" THEN
Count_Fr = Count_Fr + 1
ELSE IF Element$ = "Be" THEN
Count_Be = Count_Be + 1
ELSE IF Element$ = "Mg" THEN
Count_Mg = Count_Mg + 1
ELSE IF Element$ = "Ca" THEN
Count_Ca = Count_Ca + 1
ELSE IF Element$ = "Sr" THEN
Count_Sr = Count_Sr + 1
ELSE IF Element$ = "Ba" THEN
Count_Ba = Count_Ba + 1
ELSE IF Element$ = "Ra" THEN
Count_Ra = Count_Ra + 1
ELSE IF Element$ = "Sc" THEN
Count_Sc = Count_Sc + 1
ELSE IF Element$ = "Y" THEN
Count_Y = Count_Y + 1
ELSE IF Element$ = "La" THEN
Count_La = Count_La + 1
ELSE IF Element$ = "Ac" THEN
Count_Ac = Count_Ac + 1
ELSE IF Element$ = "Ce" THEN
Count_Ce = Count_Ce + 1
ELSE IF Element$ = "Pr" THEN
Count_Pr = Count_Pr + 1
ELSE IF Element$ = "Nd" THEN
Count_Nd = Count_Nd + 1
ELSE IF Element$ = "Pm" THEN
Count_Pm = Count_Pm + 1
ELSE IF Element$ = "Sm" THEN
Count_Sm = Count_Sm + 1
ELSE IF Element$ = "Eu" THEN
Count_Eu = Count_Eu + 1
ELSE IF Element$ = "Gd" THEN
Count_Gd = Count_Gd + 1
ELSE IF Element$ = "Tb" THEN
Count_Tb = Count_Tb + 1
ELSE IF Element$ = "Dy" THEN
Count_Dy = Count_Dy + 1
ELSE IF Element$ = "Ho" THEN
Count_Ho = Count_Ho + 1
ELSE IF Element$ = "Er" THEN
Count_Er = Count_Er + 1
ELSE IF Element$ = "Tm" THEN
Count_Tm = Count_Tm + 1
ELSE IF Element$ = "Yb" THEN
Count_Yb = Count_Yb + 1
ELSE IF Element$ = "Lu" THEN
Count_Lu = Count_Lu + 1
ELSE IF Element$ = "Th" THEN
Count_Th = Count_Th + 1
ELSE IF Element$ = "Pa" THEN
Count_Pa = Count_Pa + 1
ELSE IF Element$ = "U" THEN
Count_U = Count_U + 1
ELSE IF Element$ = "Np" THEN
Count_Np = Count_Np + 1
ELSE IF Element$ = "Pu" THEN
Count_Pu = Count_Pu + 1
ELSE IF Element$ = "Am" THEN
Count_Am = Count_Am + 1
ELSE IF Element$ = "Cm" THEN
Count_Cm = Count_Cm + 1
ELSE IF Element$ = "Bk" THEN
Count_Bk = Count_Bk + 1
ELSE IF Element$ = "Cf" THEN
Count_Cf = Count_Cf + 1
ELSE IF Element$ = "Es" THEN
Count_Es = Count_Es + 1
ELSE IF Element$ = "Fm" THEN
Count_Fm = Count_Fm + 1
ELSE IF Element$ = "Md" THEN
Count_Md = Count_Md + 1
ELSE IF Element$ = "No" THEN
Count_No = Count_No + 1
ELSE IF Element$ = "Lr" THEN
Count_Lr = Count_Lr + 1
ELSE IF Element$ = "Ti" THEN
Count_Ti = Count_Ti + 1
ELSE IF Element$ = "Zr" THEN
Count_Zr = Count_Zr + 1
ELSE IF Element$ = "Hf" THEN
Count_Hf = Count_Hf + 1
ELSE IF Element$ = "Rf" THEN
Count_Rf = Count_Rf + 1
ELSE IF Element$ = "V" THEN
Count_V = Count_V + 1
ELSE IF Element$ = "Nb" THEN
Count_Nb = Count_Nb + 1
ELSE IF Element$ = "Ta" THEN
Count_Ta = Count_Ta + 1
ELSE IF Element$ = "Db" THEN
Count_Db = Count_Db + 1
ELSE IF Element$ = "Cr" THEN
Count_Cr = Count_Cr + 1
ELSE IF Element$ = "Mo" THEN
Count_Mo = Count_Mo + 1
ELSE IF Element$ = "W" THEN
Count_W = Count_W + 1
ELSE IF Element$ = "Sg" THEN
Count_Sg = Count_Sg + 1
ELSE IF Element$ = "Mn" THEN
Count_Mn = Count_Mn + 1
ELSE IF Element$ = "Tc" THEN
Count_Tc = Count_Tc + 1
ELSE IF Element$ = "Re" THEN
Count_Re = Count_Re + 1
ELSE IF Element$ = "Bh" THEN
Count_Bh = Count_Bh + 1
ELSE IF Element$ = "Fe" THEN
Count_Fe = Count_Fe + 1
ELSE IF Element$ = "Ru" THEN
Count_Ru = Count_Ru + 1
ELSE IF Element$ = "Os" THEN
Count_Os = Count_Os + 1
ELSE IF Element$ = "Hs" THEN
Count_Hs = Count_Hs + 1
ELSE IF Element$ = "Co" THEN
Count_Co = Count_Co + 1
ELSE IF Element$ = "Rh" THEN
Count_Rh = Count_Rh + 1
ELSE IF Element$ = "Ir" THEN
Count_Ir = Count_Ir + 1
ELSE IF Element$ = "Mt" THEN
Count_Mt = Count_Mt + 1
ELSE IF Element$ = "Ni" THEN
Count_Ni = Count_Ni + 1
ELSE IF Element$ = "Pd" THEN
Count_Pd = Count_Pd + 1
ELSE IF Element$ = "Pt" THEN
Count_Pt = Count_Pt + 1
ELSE IF Element$ = "Ds" THEN
Count_Ds = Count_Ds + 1
ELSE IF Element$ = "Cu" THEN
Count_Cu = Count_Cu + 1
ELSE IF Element$ = "Ag" THEN
Count_Ag = Count_Ag + 1
ELSE IF Element$ = "Au" THEN
Count_Au = Count_Au + 1
ELSE IF Element$ = "Rg" THEN
Count_Rg = Count_Rg + 1
ELSE IF Element$ = "Zn" THEN
Count_Zn = Count_Zn + 1
ELSE IF Element$ = "Cd" THEN
Count_Cd = Count_Cd + 1
ELSE IF Element$ = "Hg" THEN
Count_Hg = Count_Hg + 1
ELSE IF Element$ = "Cn" THEN
Count_Cn = Count_Cn + 1
ELSE IF Element$ = "B" THEN
Count_B = Count_B + 1
ELSE IF Element$ = "Al" THEN
Count_Al = Count_Al + 1
ELSE IF Element$ = "Ga" THEN
Count_Ga = Count_Ga + 1
ELSE IF Element$ = "In" THEN
Count_In = Count_In + 1
ELSE IF Element$ = "Tl" THEN
Count_Tl = Count_Tl + 1
ELSE IF Element$ = "Nh" THEN
Count_Nh = Count_Nh + 1
ELSE IF Element$ = "C" THEN
Count_C = Count_C + 1
ELSE IF Element$ = "Si" THEN
Count_Si = Count_Si + 1
ELSE IF Element$ = "Ge" THEN
Count_Ge = Count_Ge + 1
ELSE IF Element$ = "Sn" THEN
Count_Sn = Count_Sn + 1
ELSE IF Element$ = "Pb" THEN
Count_Pb = Count_Pb + 1
ELSE IF Element$ = "Fl" THEN
Count_Fl = Count_Fl + 1
ELSE IF Element$ = "N" THEN
Count_N = Count_N + 1
ELSE IF Element$ = "P" THEN
Count_P = Count_P + 1
ELSE IF Element$ = "As" THEN
Count_As = Count_As + 1
ELSE IF Element$ = "Sb" THEN
Count_Sb = Count_Sb + 1
ELSE IF Element$ = "Bi" THEN
Count_Bi = Count_Bi + 1
ELSE IF Element$ = "Mc" THEN
Count_Mc = Count_Mc + 1
ELSE IF Element$ = "O" THEN
Count_O = Count_O + 1
ELSE IF Element$ = "S" THEN
Count_S = Count_S + 1
ELSE IF Element$ = "Se" THEN
Count_Se = Count_Se + 1
ELSE IF Element$ = "Te" THEN
Count_Te = Count_Te + 1
ELSE IF Element$ = "Po" THEN
Count_Po = Count_Po + 1
ELSE IF Element$ = "Lv" THEN
Count_Lv = Count_Lv + 1
ELSE IF Element$ = "F" THEN
Count_F = Count_F + 1
ELSE IF Element$ = "Cl" THEN
Count_Cl = Count_Cl + 1
ELSE IF Element$ = "Br" THEN
Count_Br = Count_Br + 1
ELSE IF Element$ = "I" THEN
Count_I = Count_I + 1
ELSE IF Element$ = "At" THEN
Count_At = Count_At + 1
ELSE IF Element$ = "Ts" THEN
Count_Ts = Count_Ts + 1
ELSE IF Element$ = "He" THEN
Count_He = Count_He + 1
ELSE IF Element$ = "Ne" THEN
Count_Ne = Count_Ne + 1
ELSE IF Element$ = "Ar" THEN
Count_Ar = Count_Ar + 1
ELSE IF Element$ = "Kr" THEN
Count_Kr = Count_Kr + 1
ELSE IF Element$ = "Xe" THEN
Count_Xe = Count_Xe + 1
ELSE IF Element$ = "Rn" THEN
Count_Rn = Count_Rn + 1
ELSE IF Element$ = "Og" THEN
Count_Og = Count_Og + 1
ENDIF

ENDIF

########################
#print Element$
#print TotNumQuery, EnergyQuery, CoordQuery

IF (TotNumQuery = 1 AND K% = 0) THEN
# count lines in the new particular structure
K% = 1
L% = L% + 1
OPEN "O", #2, "/data/data/cz.p/files/xtb/multi/multistructure_"+STR$(L%)+".xyz"
PRINT #2, TotNum
CLOSE #2
ELSE IF EnergyQuery = 1 THEN
K% = K% + 1
OPEN "A", #2, "/data/data/cz.p/files/xtb/multi/multistructure_"+STR$(L%)+".xyz"
PRINT #2, Energy
CLOSE #2
OPEN "O", #3, "/data/data/cz.p/files/xtb/multi/multistructure_"+STR$(L%)+".txt"
PRINT #3, Energy;
CLOSE #3
ELSE IF CoordQuery = 1 THEN
K% = K% + 1
OPEN "A", #2, "/data/data/cz.p/files/xtb/multi/multistructure_"+STR$(L%)+".xyz"
PRINT #2, Coord$
CLOSE #2
ELSE IF (TotNumQuery = 1 AND K% > OldTotNum+1 AND TotNum > 0) THEN
# count lines in the new particular structure
K% = 1
L% = L% + 1
OPEN "O", #2, "/data/data/cz.p/files/xtb/multi/multistructure_"+STR$(L%)+".xyz"
PRINT #2, TotNum
CLOSE #2
ENDIF
#print "I=";I%, "K=";K%, "L=";L%, "Old=";OldTotNum, TotNum, Energy, Coord$
########################

I% = I% + 1

EXIT IF (I% = 10000 OR LineData$ = "")

LOOP

CLOSE #1

EXIT

END
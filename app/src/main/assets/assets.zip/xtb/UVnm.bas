# set the normalization factor for Gaussian function
M = 0.5
# set the normalization factor for Lorentzian function
N = 0.5
# eps - max absorpt. wavelength
# x - data point
# sigma - full width at half maximum of the electronic transition / eV
sigma = 0.5

# absorbance
#PseudoVoigt = N*((1-M)*EXP(-((Energy-eps)/sigma)^2)+M/(1+4*((Energy-eps)/sigma)^2))

DIM Inp$(1000)
OPEN "O", #2, "/data/data/cz.p/files/xtb/graph-series1.csv"
CLOSE #2


lambda = 190
DO

Energy = (6.62607015e-34*299792458/(lambda*1e-9))/1.602176634e-19
Absorbance = 0





I% = 0
OPEN "I", #1, "/data/data/cz.p/files/xtb/uv7.txt"
DO
#print I%

INPUT #1, LineData$
Inp$(I%) = LineData$
Comma = INSTR(LineData$,";")
Length = LEN(LineData$)
w$ = MID$(LineData$, 1, Comma-1)

EXIT IF w$ = ""

eps = (6.62607015e-34*299792458/(VAL(w$)*1e-9))/1.602176634e-19

OscS$ = MID$(LineData$, Comma+1, Length-Comma)
OscS = VAL(OscS$)

#print "lambda=";lambda
#print "Energy=";Energy

PseudoVoigt = N*((1-M)*EXP(-((Energy-eps)/sigma)^2)+M/(1+4*((Energy-eps)/sigma)^2))
Absorbance = Absorbance + OscS*PseudoVoigt

#print "Absorbance=";Absorbance

INC I%

LOOP

CLOSE #1

OPEN "A", #2, "/data/data/cz.p/files/xtb/graph-series1.csv"
#PRINT lambda;",";Absorbance

PRINT #2, lambda;",";Absorbance

CLOSE #2
lambda=lambda+1
EXIT IF lambda > 1300
LOOP



END

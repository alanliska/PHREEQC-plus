OPEN "O", #1, "Table0-xtb.txt"
CLOSE #1

OPEN "I", #2, "Angles-xtb.txt"
OPEN "I", #3, "Energy-xtb.txt"

OPEN "A", #1, "Table0-xtb.txt"

DIM Angles$(5000)
DIM Energies$(5000)

K% = 0

DO

angle$ = ""

INPUT #2, LineAngle$
LineAngle$ = TRIM$(LineAngle$)
Angles$(K%) = LineAngle$
angle$ = XTRIM$(LineAngle$)

INPUT #3, LineEnergy$
LineEnergy$ = TRIM$(LineEnergy$)
Energies$(K%) = LineEnergy$
energy$ = XTRIM$(LineEnergy$)

K% = K% + 1
EXIT IF (K% = 4999 OR angle$ = "")

PRINT #1, angle$+","+energy$

LOOP

CLOSE #3
CLOSE #2
CLOSE #1

EXIT

END
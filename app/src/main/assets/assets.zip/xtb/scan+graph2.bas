
OPEN "O", #1, "Angles-xtb.txt"
CLOSE #1

OPEN "I", #3, "Angle-units.txt"
INPUT #3, units$
units = VAL(units$)
CLOSE #3

OPEN "I", #4, "Angle-count.txt"
INPUT #4, count$
count = VAL(count$)
CLOSE #4

DIM Inp$(5000)
OPEN "I", #2, "Output3-xtb.txt"

I% = 0
DO

INPUT #2, LineData$
Inp$(I%) = LineData$

angle_step$ = ""

FormattedLineData$ = XTRIM$(LineData$)
J% = 1
WHILE LEN(FormattedLineData$)
SPLIT FormattedLineData$," ",0,a$,FormattedLineData$
IF J% = 3 THEN
angle_step$ = a$
ENDIF
INC J%
WEND

I% = I% + 1
EXIT IF (I% = 4999 OR angle_step$ = "")

angle_step = VAL(angle_step$)
angle_recalculated = angle_step*units/count

OPEN "A", #1, "Angles-xtb.txt"
PRINT #1, angle_recalculated
CLOSE #1

LOOP

CLOSE #2

EXIT

END
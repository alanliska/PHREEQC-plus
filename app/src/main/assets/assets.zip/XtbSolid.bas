OPEN "O", #1, "/data/data/cz.p/files/reorder.xyz"
CLOSE #1

OPEN "I", #2, "/data/data/cz.p/files/xtb/Input-xtb2.xyz"

OPEN "A", #1, "/data/data/cz.p/files/reorder.xyz"
PRINT #1, CHR$(036)+"coord frac"

DIM Xyz$(10001)

K% = 0

DO

INPUT #2, LineXyz$
LineXyz$ = TRIM$(LineXyz$)
Xyz$(K%) = LineXyz$

Element$ = ""
X$ = ""
Y$ = ""
Z$ = ""

J% = 1
WHILE LEN(LineXyz$)
SPLIT LineXyz$," ",0,a$,LineXyz$
IF J% = 1 THEN
Element$ = a$
ELSE IF J% = 2 THEN
X$ = a$
ELSE IF J% = 3 THEN
Y$ = a$
ELSE IF J% = 4 THEN
Z$ = a$
ENDIF
INC J%
WEND

EXIT IF (K% = 10000 OR Element$ = "")
PRINT #1, X$, Y$, Z$, Element$

K% = K% + 1

LOOP

OPEN "I", #3, "/data/data/cz.p/files/XtbSolid.inp"
INPUT #3, Cell$

PRINT #1, CHR$(036)+"periodic 3"
PRINT #1, CHR$(036)+"cell"
PRINT #1, Cell$
PRINT #1, CHR$(036)+"end"

CLOSE #1
CLOSE #2
CLOSE #3
EXIT
END


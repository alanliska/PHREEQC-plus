CLS

OPEN "I", #1, "/data/data/cz.p/files/GCM3Kin.inp"
INPUT #1, Text$
CLOSE #1

Del1% = INSTR(Text$, ";")
Del2% = INSTR(Text$, ";", Del1%+1)
Del3% = INSTR(Text$, ";", Del2%+1)
Del4% = INSTR(Text$, ";", Del3%+1)
Del5% = INSTR(Text$, ";", Del4%+1)
Del6% = INSTR(Text$, ";", Del5%+1)
Del7% = INSTR(Text$, ";", Del6%+1)
Del8% = INSTR(Text$, ";", Del7%+1)
Del9% = INSTR(Text$, ";", Del8%+1)
Del10% = INSTR(Text$, ";", Del9%+1)
Del11% = INSTR(Text$, ";", Del10%+1)
Del12% = INSTR(Text$, ";", Del11%+1)
Del13% = INSTR(Text$, ";", Del12%+1)

TextLen% = LEN(Text$)

A$ = MID$(Text$, 1, Del1%-1)
ca$ = MID$(Text$, Del1%+1, Del2%-Del1%-1)
ca = VAL(ca$)
B$ = MID$(Text$, Del2%+1, Del3%-Del2%-1)
cb$ = MID$(Text$, Del3%+1, Del4%-Del3%-1)
cb = VAL(cb$)
K$ = MID$(Text$, Del4%+1, Del5%-Del4%-1)
ck$ = MID$(Text$, Del5%+1, Del6%-Del5%-1)
ck = VAL(ck$)
C$ = MID$(Text$, Del6%+1, Del7%-Del6%-1)
cc$ = MID$(Text$, Del7%+1, Del8%-Del7%-1)
cc = VAL(cc$)
D$ = MID$(Text$, Del8%+1, Del9%-Del8%-1)
cd$ = MID$(Text$, Del9%+1, Del10%-Del9%-1)
cd = VAL(cd$)
L$ = MID$(Text$, Del10%+1, Del11%-Del10%-1)
cl$ = MID$(Text$, Del11%+1, Del12%-Del11%-1)
cl = VAL(cl$)
n$ = MID$(Text$, Del12%+1, Del13%-Del12%-1)
n = VAL(n$)
Title$ = MID$(Text$, Del13%+1, TextLen%-Del13%)

OPEN "I", #2, "/data/data/cz.p/files/GCM3Kin.par"
INPUT #2, Z
CLOSE #2

DIM TabulatedData$(200)

OPEN "I", #3, "/data/data/cz.p/files/GCM3Kin.dat"

FOR I% = 0 TO 199

INPUT #3, LineText$
TabulatedData$(I%) = LineText$
DataLen% = LEN(LineText$)
Del14% = INSTR(LineText$, ";")
Del15% = INSTR(LineText$, ";", Del14%+1)
Del16% = INSTR(LineText$, ";", Del15%+1)

Ox$ = MID$(LineText$, 1, Del14%-1)
Red$ = MID$(LineText$, Del14%+1, Del15%-Del14%-1)
log_k11$ = MID$(LineText$, Del15%+1, Del16%-Del15%-1)
log_k11 = VAL(log_k11$)
E0$ = MID$(LineText$, Del16%+1, DataLen%-Del16%)
E0 = VAL(E0$)

IF Ox$ = A$ THEN
k11 = 10^log_k11
E1 = E0
Oxid1$ = Ox$
ENDIF

IF Red$ = B$ THEN
k22 = 10^log_k11
E2 = E0
Reduc1$ = Red$
ENDIF

EXIT IF Ox$ = ""
NEXT I%

CLOSE #3

E12 = E1-E2
log_K = 16.9*n*E12
K = 10^log_K
log_f = ((log_K)^2)/(4*LOG10(k11*k22/Z^2))
f = 10^log_f
k12 = (k11*k22*K*f)^0.5
k21 = k12/K

IF INSTR(A$, "+") > 0 THEN
SignA$ = MID$(A$, INSTR(A$, "+"), LEN(A$)-INSTR(A$, "+")+1)
ELSE IF INSTR(A$, "-") > 0 THEN
SignA$ = MID$(A$, INSTR(A$, "-"), LEN(A$)-INSTR(A$, "-")+1)
ELSE
SignA$ = ""
ENDIF

IF INSTR(B$, "+") > 0 THEN
SignB$ = MID$(B$, INSTR(B$, "+"), LEN(B$)-INSTR(B$, "+")+1)
ELSE IF INSTR(B$, "-") > 0 THEN
SignB$ = MID$(B$, INSTR(B$, "-"), LEN(B$)-INSTR(B$, "-")+1)
ELSE
SignB$ = ""
ENDIF

IF INSTR(K$, "+") > 0 THEN
SignK$ = MID$(K$, INSTR(K$, "+"), LEN(K$)-INSTR(K$, "+")+1)
ELSE IF INSTR(K$, "-") > 0 THEN
SignK$ = MID$(K$, INSTR(K$, "-"), LEN(K$)-INSTR(K$, "-")+1)
ELSE
SignK$ = ""
ENDIF

IF INSTR(C$, "+") > 0 THEN
SignC$ = MID$(C$, INSTR(C$, "+"), LEN(C$)-INSTR(C$, "+")+1)
ELSE IF INSTR(C$, "-") > 0 THEN
SignC$ = MID$(C$, INSTR(C$, "-"), LEN(C$)-INSTR(C$, "-")+1)
ELSE
SignC$ = ""
ENDIF

IF INSTR(D$, "+") > 0 THEN
SignD$ = MID$(D$, INSTR(D$, "+"), LEN(D$)-INSTR(D$, "+")+1)
ELSE IF INSTR(D$, "-") > 0 THEN
SignD$ = MID$(D$, INSTR(D$, "-"), LEN(D$)-INSTR(D$, "-")+1)
ELSE
SignD$ = ""
ENDIF

IF INSTR(L$, "+") > 0 THEN
SignL$ = MID$(L$, INSTR(L$, "+"), LEN(L$)-INSTR(L$, "+")+1)
ELSE IF INSTR(L$, "-") > 0 THEN
SignL$ = MID$(L$, INSTR(L$, "-"), LEN(L$)-INSTR(L$, "-")+1)
ELSE IF (INSTR(L$, "+") = 0 AND INSTR(L$, "-") = 0) THEN
SignL$ = ""
ENDIF

IF SignA$ = "+" THEN
SignA = 1
ELSE IF SignA$ = "-" THEN
SignA = -1
ELSE
SignA = VAL(SignA$)
ENDIF

IF SignB$ = "+" THEN
SignB = 1
ELSE IF SignB$ = "-" THEN
SignB = -1
ELSE
SignB = VAL(SignB$)
ENDIF

IF SignC$ = "+" THEN
SignC = 1
ELSE IF SignC$ = "-" THEN
SignC = -1
ELSE
SignC = VAL(SignC$)
ENDIF

IF SignD$ = "+" THEN
SignD = 1
ELSE IF SignD$ = "-" THEN
SignD = -1
ELSE
SignD = VAL(SignD$)
ENDIF

IF SignK$ = "+" THEN
SignK = 1
ELSE IF SignK$ = "-" THEN
SignK = -1
ELSE
SignK = VAL(SignK$)
ENDIF

IF SignL$ = "+" THEN
SignL = 1
ELSE IF SignL$ = "-" THEN
SignL = -1
ELSE
SignL = VAL(SignL$)
ENDIF

OPEN "A", #4, "/data/data/cz.p/files/GCM3Kin_R.out"
PRINT #4, Title$;
PRINT #4, " ; -start";
PRINT #4, " ; 10 if (MOL("+CHR$(34)+"["+A$+"]"+SignA$+CHR$(34)+") <= 1e-15) then goto 200";
PRINT #4, " ; 20 if (MOL("+CHR$(34)+"["+B$+"]"+SignB$+CHR$(34)+") <= 1e-15) then goto 200";
IF K$ <> "0" THEN
PRINT #4, " ; 30 if (MOL("+CHR$(34)+"["+K$+"]"+SignK$+CHR$(34)+") <= 1e-15) then goto 200";
ENDIF
PRINT #4, " ; 100 moles = "+STR$(k12)+" * MOL("+CHR$(34)+"["+A$+"]"+SignA$+CHR$(34)+") * MOL("+CHR$(34)+"["+B$+"]"+SignB$+CHR$(34)+")";
PRINT #4, " ; 200 SAVE moles";
PRINT #4, " ; -end"
CLOSE #4,


OPEN "A", #10, "/data/data/cz.p/files/GCM3Kin_K.out"
PRINT #10, Title$;
PRINT #10, " ; -formula ["+A$+"]"+SignA$+" "+STR$(-ca)+" ["+B$+"]"+SignB$+" "+STR$(-cb);
IF ck <> 0 THEN
PRINT #10, " ["+K$+"]"+SignK$+" "+STR$(-ck);
ENDIF
IF cl <> 0 THEN
PRINT #10, " ["+C$+"]"+SignC$+" "+STR$(cc)+" ["+D$+"]"+SignD$+" "+STR$(cd);
PRINT #10, " ["+L$+"]"+SignL$+" "+STR$(cl)
ELSE
PRINT #10, " ["+C$+"]"+SignC$+" "+STR$(cc)+" ["+D$+"]"+SignD$+" "+STR$(cd)
ENDIF
CLOSE #10

OPEN "A", #13, "/data/data/cz.p/files/GCM3Kin_SMS.out"
PRINT #13, "["+A$+"]", "["+A$+"]"+SignA$, "0", "["+A$+"]", 1
PRINT #13, "["+B$+"]", "["+B$+"]"+SignB$, "0", "["+B$+"]", 1
IF ck <> 0 THEN
PRINT #13, "["+K$+"]", "["+K$+"]"+SignK$, "0", "["+K$+"]", 1
ENDIF
PRINT #13, "["+C$+"]", "["+C$+"]"+SignC$, "0", "["+C$+"]", 1
PRINT #13, "["+D$+"]", "["+D$+"]"+SignD$, "0", "["+D$+"]", 1
IF cl <> 0 THEN
PRINT #13, "["+L$+"]", "["+L$+"]"+SignL$, "0", "["+L$+"]", 1
ENDIF
CLOSE #13

OPEN "A", #14, "/data/data/cz.p/files/GCM3Kin_SS.out"
PRINT #14, #14, "["+A$+"]"+SignA$;" = ";"["+A$+"]"+SignA$
PRINT #14, #14, "["+B$+"]"+SignB$;" = ";"["+B$+"]"+SignB$
IF ck <> 0 THEN
PRINT #14, #14, "["+K$+"]"+SignK$;" = ";"["+K$+"]"+SignK$
ENDIF
PRINT #14, #14, "["+C$+"]"+SignC$;" = ";"["+C$+"]"+SignC$
PRINT #14, #14, "["+D$+"]"+SignD$;" = ";"["+D$+"]"+SignD$
IF cl <> 0 THEN
PRINT #14, #14, "["+L$+"]"+SignL$;" = ";"["+L$+"]"+SignL$
ENDIF
CLOSE #14

EXIT

END

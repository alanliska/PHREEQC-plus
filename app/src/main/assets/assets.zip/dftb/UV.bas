# set the normalization factor for Gaussian function
M = 0.5
# set the normalization factor for Lorentzian function
N = 0.5
# eps - max absorpt. wavelength
# x - data point
# sigma - full width at half maximum of the electronic transition / eV
sigma = 0.5

# absorbance
#PseudoVoigt = N*((1-M)*EXP(-((Energy-eps)/sigma)^2)+M/(1+4*((Energy-eps)/sigma)^2))

DIM Inp$(250)
OPEN "O", #2, "/data/data/cz.p/files/dftb/spectrum.csv"
CLOSE #2


lambda = 190
DO

Energy = (6.62607015e-34*299792458/(lambda*1e-9))/1.602176634e-19
#print "Energy=";Energy
Absorbance = 0





I% = 0
OPEN "I", #1, "/data/data/cz.p/files/dftb/EXC.DAT"
DO
#print I%

INPUT #1, LineData$
Inp$(I%) = LineData$
#print LineData$
#IF I% > 1 THEN
w$ = LEFT$(LineData$, 13)
eps = VAL(w$)
#print "eps=";eps
OscS$ = MID$(LineData$, 14, 18)
OscS = VAL(OscS$)
#print "OscS=";OscS
PseudoVoigt = N*((1-M)*EXP(-((Energy-eps)/sigma)^2)+M/(1+4*((Energy-eps)/sigma)^2))
Absorbance = Absorbance + OscS*PseudoVoigt
#print "Abs=";Absorbance
#ENDIF
INC I%
EXIT IF (I%>5 AND LineData$ = "")
LOOP

CLOSE #1

OPEN "A", #2, "/data/data/cz.p/files/dftb/spectrum.csv"
PRINT lambda;",";Absorbance

PRINT #2, lambda;",";Absorbance

CLOSE #2
lambda=lambda+1
EXIT IF lambda > 1300
LOOP



END

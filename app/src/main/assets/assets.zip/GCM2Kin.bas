CLS

OPEN "I", #2, "/data/data/cz.p/files/GCM2Kin.inp"
INPUT #2, Cation$, Anion$, Dist, Exchanged$, Leaving$, Title$
CLOSE #2

OPEN "I", #3, "/data/data/cz.p/files/GCM2Kin.par"
INPUT #3, a, b, c, d, e
CLOSE #3

SeekCation% = INSTR(Cation$, "+")
SeekAnion% = INSTR(Anion$, "-")
LengthCation% = LEN(Cation$)
LengthAnion% = LEN(Anion$)
CatWord$ = LEFTOF$(Cation$, "+")
AnWord$ = LEFTOF$(Anion$, "-")
IF SeekCation% = LengthCation% THEN
zCat = 1
ELSE IF SeekCation% < LengthCation% THEN
zCat$ = MID$(Cation$, SeekCation%+1, LengthCation%-SeekCation%)
zCat = VAL(zCat$)
ENDIF
IF SeekAnion% = LengthAnion% THEN
zAn = -1
ELSE IF SeekAnion% < LengthAnion% THEN
zAn$ = MID$(Anion$, SeekAnion%+1, LengthAnion%-SeekAnion%)
zAn = -VAL(zAn$)
ELSE IF SeekAnion% = 0 THEN
z = 0
ENDIF

IF Dist = 0 THEN
Distance = (ABS(zCat*zAn)*(4.80e-10)^2)/(3*c*1.38e-16*d)
ELSE IF Dist > 0 THEN
Distance = Dist*1e-10
ENDIF

Theta = SQRT((8*PI*6.022e23*(4.80e-10)^2*b)/(e*c*1.38e-16*d))

Ua = (zCat*ZAn*(4.80e-10)^2/(Distance*c)) - (zCat*zAn*(4.80e-10)^2*Theta/(c*(1+Distance*Theta)))

Kos = (4*PI*6.022e23*(Distance)^3/a) * EXP(-Ua / (1.38e-16*d))

log_k = LOG10(Kos)

DIM NextData$(200)

OPEN "I", #4, "/data/data/cz.p/files/GCM2Kin.dat"

FOR I% = 0 TO 199
INPUT #4, Line$
NextData$(I%) = Line$
DataLen% = LEN(Line$)
Del1% = INSTR(Line$, ";")
Metal$ = MID$(Line$, 1, Del1%-1)
Num$ = MID$(Line$, Del1%+1, DataLen%-Del1%)
Num = VAL(Num$)

IF Metal$ = Cation$ THEN
log_kw = Num
ENDIF

EXIT IF Metal$ = ""
NEXT I%

CLOSE #4

kw = 10^log_kw

IF INSTR(Cation$, "+") <> 0 THEN
SignA$ = MID$(Cation$, INSTR(Cation$, "+"), LEN(Cation$)-INSTR(Cation$, "+")+1)
IF SignA$ = "+" THEN
SignA = 1
ELSE
SignA = VAL(SignA$)
ENDIF
ELSE
SignA = 0
ENDIF

IF INSTR(Anion$, "-") <> 0 THEN
SignB$ = MID$(Anion$, INSTR(Anion$, "-"), LEN(Anion$)-INSTR(Anion$, "-")+1)
IF SignB$ = "-" THEN
SignB = -1
ELSE
SignB = VAL(SignB$)
ENDIF
ELSE
SignB = 0
ENDIF

IF INSTR(Exchanged$, "+") <> 0 THEN
SignC$ = MID$(Exchanged$, INSTR(Exchanged$, "+"), LEN(Exchanged$)-INSTR(Exchanged$, "+")+1)
IF SignC$ = "+" THEN
SignC = 1
ELSE
SignC = VAL(SignC$)
ENDIF
ELSE IF INSTR(Exchanged$, "-") <> 0 THEN
SignC$ = MID$(Exchanged$, INSTR(Exchanged$, "-"), LEN(Exchanged$)-INSTR(Exchanged$, "-")+1)
IF SignC$ = "-" THEN
SignC = -1
ELSE
SignC = VAL(SignC$)
ENDIF
ELSE
SignC = 0
ENDIF

IF INSTR(Leaving$, "-") <> 0 THEN
SignD$ = MID$(Leaving$, INSTR(Leaving$, "-"), LEN(Leaving$)-INSTR(Leaving$, "-")+1)
IF SignD$ = "-" THEN
SignD = -1
ELSE
SignD = VAL(SignD$)
ENDIF
ELSE
SignD = 0
ENDIF

OPEN "A", #1, "/data/data/cz.p/files/GCM2Kin_R.out"
PRINT #1, Title$;
PRINT #1, " ; -start";
PRINT #1, " ; 10 if (MOL("+CHR$(34)+"["+Cation$+"]"+SignA$+CHR$(34)+") <= 1e-15) then goto 200";
IF Anion$ <> "H2O" THEN
PRINT #1, " ; 20 if (MOL("+CHR$(34)+"["+Anion$+"]"+SignB$+CHR$(34)+") <= 1e-15) then goto 200";
ENDIF
IF Anion$ <> "H2O" THEN
PRINT #1, " ; 100 moles = "+STR$(kw)+" * "+STR$(Kos)+" * MOL("+CHR$(34)+"["+Cation$+"]"+SignA$+CHR$(34)+") * MOL("+CHR$(34)+"["+Anion$+"]"+SignB$+CHR$(34)+")";
ELSE
PRINT #1, " ; 100 moles = "+STR$(kw)+" * "+STR$(Kos)+" * MOL("+CHR$(34)+"["+Cation$+"]"+SignA$+CHR$(34)+") * 55.5)";
ENDIF
PRINT #1, " ; 200 SAVE moles";
PRINT #1, " ; -end"
CLOSE #1

OPEN "A", #10, "/data/data/cz.p/files/GCM2Kin_K.out"
PRINT #10, Title$;
PRINT #10, " ; -formula ["+Cation$+"]"+SignA$+" -1";
IF Anion$ <> "H2O" THEN
PRINT #10, " ["+Anion$+"]"+SignB$+" -1";
ENDIF
PRINT #10, " ["+Exchanged$+"]"+SignC$+" 1";
IF Leaving$ <> "H2O" THEN
PRINT #10, " ["+Leaving$+"]"+SignD$+" 1"
ELSE
PRINT #10, ""
ENDIF
CLOSE #10

OPEN "A", #13, "/data/data/cz.p/files/GCM2Kin_SMS.out"
PRINT #13, "["+Cation$+"]", "["+Cation$+"]"+SignA$, "0", "["+Cation$+"]", 1
IF Anion$ <> "H2O" THEN
PRINT #13, "["+Anion$+"]", "["+Anion$+"]"+SignB$, "0", "["+Anion$+"]", 1
ENDIF
PRINT #13, "["+Exchanged$+"]", "["+Exchanged$+"]"+SignC$, "0", "["+Exchanged$+"]", 1
IF Leaving$ <> "H2O" THEN
PRINT #13, "["+Leaving$+"]", "["+Leaving$+"]"+SignD$, "0", "["+Leaving$+"]", 1
ENDIF
CLOSE #13

OPEN "A", #14, "/data/data/cz.p/files/GCM2Kin_SS.out"
PRINT #14, "["+Cation$+"]"+SignA$;" = ";"["+Cation$+"]"+SignA$
IF Anion$ <> "H2O" THEN
PRINT #14, "["+Anion$+"]"+SignB$;" = ";"["+Anion$+"]"+SignB$
ENDIF
PRINT #14, "["+Exchanged$+"]"+SignC$;" = ";"["+Exchanged$+"]"+SignC$
IF Leaving$ <> "H2O" THEN
PRINT #14, "["+Leaving$+"]"+SignD$;" = ";"["+Leaving$+"]"+SignD$
ENDIF
CLOSE #14

EXIT

END

latex mopac
bibtex mopac
latex mopac
latex mopac
makeindex mopac
latex mopac
latex mopac
latex2html -no_footnode mopac

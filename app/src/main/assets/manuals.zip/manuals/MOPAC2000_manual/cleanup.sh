rm *.aux *.bbl *.blg *.dvi *.idx *.lof *.lot *.log *.toc *.ilg *.ind
